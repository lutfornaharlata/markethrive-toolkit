#!/usr/bin/env python3
"""
MarketHrive — Import scraped logos + emails CSV to production.

Used by the assistant (not by the user). When user uploads logos_found.csv
or emails_found.csv, this script reads them and updates production DB.

CSV format (must match what scrape.py produces):
  logos_found.csv:  business_id, logo_url
  emails_found.csv: business_id, email

Usage (assistant runs this):
    python import_scraped.py --logos /path/to/logos_found.csv
    python import_scraped.py --emails /path/to/emails_found.csv
    python import_scraped.py --logos logos.csv --emails emails.csv  # both
"""
import argparse, csv, sys, time
import psycopg2
import requests

DB_PASS = "q3eaBQD6255BY+B"
PROJ = "iuguoryuevjnmdejvwes"
REGION = "ap-northeast-1"
BREVO_KEY = "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"
BREVO_LIST_ID = 2

def import_logos(csv_path):
    """Update DB.logoUrl from CSV."""
    print(f"=== Importing logos from {csv_path} ===")
    with open(csv_path, encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    print(f"  Loaded {len(rows)} logo rows")

    conn = psycopg2.connect(host=f"aws-0-{REGION}.pooler.supabase.com",
        port=6543, dbname="postgres",
        user=f"postgres.{PROJ}", password=DB_PASS, connect_timeout=15)
    conn.autocommit = False
    cur = conn.cursor()

    updated = 0; skipped = 0; errors = 0
    for r in rows:
        bid = r.get('business_id', '').strip()
        logo_url = r.get('logo_url', '').strip()
        if not bid or not logo_url:
            skipped += 1
            continue
        try:
            cur.execute(
                'UPDATE "Business" SET "logoUrl" = %s, "updatedAt" = NOW() WHERE id = %s AND "logoUrl" IS NULL',
                (logo_url, bid)
            )
            if cur.rowcount > 0:
                updated += 1
            else:
                skipped += 1
            conn.commit()
        except Exception as e:
            conn.rollback()
            errors += 1
            if errors <= 3:
                print(f"  ⚠ ERROR {bid}: {str(e)[:80]}")

    print(f"\n  Updated:  {updated}")
    print(f"  Skipped:  {skipped}")
    print(f"  Errors:   {errors}")

    cur.execute('SELECT COUNT(*) FROM "Business" WHERE "logoUrl" IS NOT NULL')
    print(f"  Total logos in DB now: {cur.fetchone()[0]}")
    cur.close(); conn.close()


def import_emails(csv_path):
    """Update DB.email from CSV + sync to Brevo."""
    print(f"=== Importing emails from {csv_path} ===")
    with open(csv_path, encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    print(f"  Loaded {len(rows)} email rows")

    conn = psycopg2.connect(host=f"aws-0-{REGION}.pooler.supabase.com",
        port=6543, dbname="postgres",
        user=f"postgres.{PROJ}", password=DB_PASS, connect_timeout=15)
    conn.autocommit = False
    cur = conn.cursor()

    updated = 0; skipped = 0; errors = 0; brevo_synced = 0
    for r in rows:
        bid = r.get('business_id', '').strip()
        email = r.get('email', '').strip().lower()
        if not bid or not email or '@' not in email:
            skipped += 1
            continue
        try:
            # Update DB
            cur.execute(
                'UPDATE "Business" SET email = %s, "emailPublic" = FALSE, "updatedAt" = NOW() WHERE id = %s AND (email IS NULL OR email = \'\')',
                (email, bid)
            )
            if cur.rowcount > 0:
                updated += 1
                conn.commit()

                # Get business name + city for Brevo sync
                cur.execute('''SELECT b.name, ci.name, st.code
                               FROM "Business" b
                               LEFT JOIN "City" ci ON b."cityId" = ci.id
                               LEFT JOIN "State" st ON ci."stateId" = st.id
                               WHERE b.id = %s''', (bid,))
                info = cur.fetchone()
                if info:
                    name, city, state = info
                    city_state = f"{city}, {state}" if city and state else ""
                    # Sync to Brevo
                    try:
                        payload = {
                            'email': email,
                            'attributes': {
                                'FIRSTNAME': (name or '')[:100],
                                'LASTNAME': city_state[:100],
                            },
                            'listIds': [BREVO_LIST_ID],
                            'updateEnabled': True,
                        }
                        resp = requests.post('https://api.brevo.com/v3/contacts',
                            headers={'api-key': BREVO_KEY, 'Content-Type': 'application/json'},
                            json=payload, timeout=15)
                        if resp.status_code in (200, 201, 204):
                            brevo_synced += 1
                    except: pass
            else:
                skipped += 1
                conn.commit()
        except Exception as e:
            conn.rollback()
            errors += 1
            if errors <= 3:
                print(f"  ⚠ ERROR {bid}: {str(e)[:80]}")

    print(f"\n  Updated:        {updated}")
    print(f"  Brevo synced:   {brevo_synced}")
    print(f"  Skipped:        {skipped}")
    print(f"  Errors:         {errors}")

    cur.execute('SELECT COUNT(*) FROM "Business" WHERE email IS NOT NULL AND email != \'\'')
    print(f"  Total emails in DB now: {cur.fetchone()[0]}")
    cur.close(); conn.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--logos', help='Path to logos_found.csv')
    ap.add_argument('--emails', help='Path to emails_found.csv')
    args = ap.parse_args()

    if not args.logos and not args.emails:
        print("Specify --logos and/or --emails CSV path")
        return

    if args.logos:
        import_logos(args.logos)
        print()
    if args.emails:
        import_emails(args.emails)


if __name__ == '__main__':
    main()
