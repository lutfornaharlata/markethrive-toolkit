#!/usr/bin/env python3
"""
MarketHrive — Download business targets list from production.

Fetches all businesses (or filtered subset) from production Supabase
and saves to targets.csv for local scraping.

Usage:
    python download_targets.py
    python download_targets.py --city Birmingham
    python download_targets.py --niche roofing
    python download_targets.py --need-logo      # only businesses missing logo
    python download_targets.py --need-email     # only businesses missing email
"""
import argparse, csv, sys
import requests
import psycopg2

DB_PASS = "q3eaBQD6255BY+B"
PROJ = "iuguoryuevjnmdejvwes"
REGION = "ap-northeast-1"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--city', default='', help='Filter by city name (partial match)')
    ap.add_argument('--niche', default='', help='Filter by niche slug (e.g. roofing)')
    ap.add_argument('--need-logo', action='store_true', help='Only businesses without logo')
    ap.add_argument('--need-email', action='store_true', help='Only businesses without email')
    ap.add_argument('--limit', type=int, default=0, help='Max businesses (0 = all)')
    ap.add_argument('--output', default='targets.csv', help='Output CSV path')
    args = ap.parse_args()

    print("=== MarketHrive — Downloading targets ===")
    conn = psycopg2.connect(
        host=f"aws-0-{REGION}.pooler.supabase.com",
        port=6543, dbname="postgres",
        user=f"postgres.{PROJ}", password=DB_PASS,
        connect_timeout=15
    )
    cur = conn.cursor()

    # Build query with niche slug lookup
    query = '''
        SELECT b.id, b.name, b.website, b.email, b."logoUrl",
               n.slug as niche_slug, ci.name as city_name, st.code as state_code
        FROM "Business" b
        LEFT JOIN "Niche" n ON b."nicheId" = n.id
        LEFT JOIN "City" ci ON b."cityId" = ci.id
        LEFT JOIN "State" st ON ci."stateId" = st.id
        WHERE b.website IS NOT NULL AND b.website != ''
          AND b.website LIKE 'http%%'
          AND b.website NOT LIKE '%%+1%%'
          AND b.website NOT LIKE '%%(%%'
    '''
    params = []
    if args.city:
        query += " AND ci.name ILIKE %s"
        params.append(f"%{args.city}%")
    if args.niche:
        query += " AND n.slug = %s"
        params.append(args.niche)
    if args.need_logo:
        query += ' AND b."logoUrl" IS NULL'
    if args.need_email:
        query += " AND (b.email IS NULL OR b.email = '')"
    query += ' ORDER BY b."reviewCount" DESC NULLS LAST'
    if args.limit > 0:
        query += f" LIMIT {args.limit}"

    cur.execute(query, params)
    rows = cur.fetchall()

    print(f"Found {len(rows)} businesses")
    if not rows:
        print("No businesses match the criteria.")
        return

    # Write CSV
    with open(args.output, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['business_id', 'name', 'website', 'current_email', 'current_logo',
                         'niche_slug', 'city', 'state_code'])
        for r in rows:
            writer.writerow([r[0], r[1], r[2], r[3] or '', r[4] or '', r[5], r[6], r[7]])

    print(f"\n✅ Saved to {args.output}")
    print(f"   Next: python scrape.py")

    # Summary
    with_logo = sum(1 for r in rows if r[4])
    with_email = sum(1 for r in rows if r[3])
    print(f"\nStats:")
    print(f"  Total:           {len(rows)}")
    print(f"  Already has logo: {with_logo}")
    print(f"  Already has email: {with_email}")
    print(f"  Need logo:        {len(rows) - with_logo}")
    print(f"  Need email:       {len(rows) - with_email}")

    cur.close()
    conn.close()

if __name__ == '__main__':
    main()
